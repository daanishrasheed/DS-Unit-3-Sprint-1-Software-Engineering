from acme import BoxingGlove
glove = BoxingGlove('Punchy the Third')
print(glove.price)
print(glove.weight)
print(glove.punch())
print(glove.explode())